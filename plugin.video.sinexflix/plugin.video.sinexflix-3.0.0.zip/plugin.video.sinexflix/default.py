# -*- coding: utf-8 -*-
"""
Sinexflix - addon Kodi para descobrir filmes e séries.

O código fica em resources/lib/:
  common.py    configurações, idioma, rede com cache, itens de lista
  router.py    recebe a URL do Kodi e chama a tela certa
  views.py     as telas (menus, catálogo, acervo, TV ao vivo, busca...)
  cinemeta.py  catálogo e informações (Cinemeta)
  tmdb.py      "Onde assistir" (TMDB / JustWatch)
  archive.py   acervo público (Internet Archive)
  live.py      TV ao vivo, teste de canais e troca de fonte
  library.py   exporta os clássicos da Minha Lista para a biblioteca do Kodi
  kids.py      modo infantil com senha
  storage.py   Minha Lista, assistidos e histórico de buscas
  upcoming.py  próximos episódios
  local.py     pasta local de vídeos
"""

from resources.lib import router

if __name__ == "__main__":
    router.run()
