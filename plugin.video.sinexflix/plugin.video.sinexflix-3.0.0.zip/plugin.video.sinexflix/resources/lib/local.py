# -*- coding: utf-8 -*-
"""Biblioteca local: navega pela pasta de vídeos configurada pelo usuário."""

import os
import re

import xbmcvfs

from .common import (ADDON, _, add_folder, add_playable, end_dir, notify, setting)

VIDEO_EXT = (".mp4", ".mkv", ".avi", ".mov", ".m4v", ".wmv", ".mpg", ".mpeg",
             ".ts", ".m2ts", ".webm", ".ogv", ".flv", ".3gp", ".iso", ".strm")


def browse(path=None):
    root = setting("local_path")
    if not root:
        notify(_("Choose your video folder in the settings"))
        ADDON.openSettings()
        end_dir()
        return
    path = path or root
    if not path.endswith(("/", "\\")):
        path += "/"
    try:
        dirs, files = xbmcvfs.listdir(path)
    except Exception as exc:
        notify(_("Could not open the folder: {}").format(exc))
        end_dir()
        return
    for d in sorted(dirs, key=str.lower):
        if d.startswith("."):
            continue
        add_folder(d, art={"icon": "DefaultFolder.png", "thumb": "DefaultFolder.png"},
                   mode="local", path=path + d)
    for f in sorted(files, key=str.lower):
        if not f.lower().endswith(VIDEO_EXT):
            continue
        name = os.path.splitext(f)[0]
        clean = re.sub(r"[._]+", " ", name).strip()
        info = {"title": clean, "mediatype": "video"}
        ym = re.search(r"\b(19\d{2}|20\d{2})\b", clean)
        if ym:
            info["year"] = int(ym.group(1))
        thumb = None
        for ext in (".jpg", ".png", "-poster.jpg", "-thumb.jpg"):
            if name + ext in files:
                thumb = path + name + ext
                break
        art = {"thumb": thumb, "poster": thumb} if thumb else {"thumb": "DefaultVideo.png"}
        add_playable(clean, path + f, art, info)
    end_dir("movies", category=os.path.basename(path.rstrip("/\\")) or _("Library"), sort=True)
