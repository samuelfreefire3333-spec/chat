# -*- coding: utf-8 -*-
"""
Biblioteca do Kodi: os filmes do acervo público que estão na Minha Lista
viram arquivos .strm + .nfo numa pasta. Adicionando essa pasta como fonte
de "Filmes" no Kodi, eles aparecem na biblioteca com capa e sinopse.
"""

import os
import re
from xml.sax.saxutils import escape

import xbmc
import xbmcgui
import xbmcvfs

from . import archive
from .common import (ADDON_ID, PROFILE, _, build_url, first, log, notify, read_json_file,
                     setting, setting_bool, strip_html, write_json_file)

MARKER = "plugin://{}/".format(ADDON_ID)
HELP_FLAG = os.path.join(PROFILE, "biblioteca_ajuda.json")


def enabled():
    return setting_bool("library_sync")


def folder():
    custom = (setting("library_path") or "").strip()
    path = custom or "special://profile/addon_data/{}/biblioteca/".format(ADDON_ID)
    return path if path.endswith(("/", "\\")) else path + _sep(path)


def _sep(path):
    return "\\" if ("\\" in path and "://" not in path) else "/"


def _join(base, *parts):
    sep = _sep(base)
    return base + sep.join(parts) + (sep if parts and not parts[-1].endswith((".strm", ".nfo")) else "")


def _scan():
    xbmc.executebuiltin('UpdateLibrary(video,"{}")'.format(xbmcvfs.translatePath(folder())))


def _safe(name):
    name = re.sub(r'[\\/:*?"<>|]+', " ", name or "").strip(" .")
    return re.sub(r"\s+", " ", name)[:120] or "Filme"


def _movie_dir(entry):
    title = _safe(entry.get("name"))
    if entry.get("year"):
        title = "{} ({})".format(title, entry["year"])
    return title


def _write(path, text):
    f = xbmcvfs.File(path, "w")
    try:
        f.write(text)
    finally:
        f.close()


def export(entry):
    if entry.get("kind") != "ia":
        return False
    name = _movie_dir(entry)
    target = _join(folder(), name)
    xbmcvfs.mkdirs(target)
    url = build_url(mode="ia_play", id=entry["id"])
    _write(target + name + ".strm", url)

    plot, runtime = "", ""
    try:
        md = archive.metadata(entry["id"]).get("metadata", {})
        plot = strip_html(first(md.get("description")))
        secs = archive.parse_runtime(md.get("runtime"))
        runtime = str(secs // 60) if secs else ""
    except Exception as exc:
        log("Sem sinopse para {}: {}".format(entry["id"], exc))
    poster = archive.IA_IMG + entry["id"]
    nfo = (
        '<?xml version="1.0" encoding="UTF-8" standalone="yes"?>\n<movie>\n'
        "  <title>{t}</title>\n  <year>{y}</year>\n  <plot>{p}</plot>\n"
        "  <runtime>{r}</runtime>\n"
        '  <thumb aspect="poster">{img}</thumb>\n'
        "  <fanart><thumb>{img}</thumb></fanart>\n"
        '  <uniqueid type="archive" default="true">{id}</uniqueid>\n'
        "  <genre>{g}</genre>\n  <tag>Sinexflix</tag>\n</movie>\n"
    ).format(t=escape(entry.get("name", "")), y=escape(str(entry.get("year") or "")),
             p=escape(plot), r=runtime, img=escape(poster), id=escape(entry["id"]),
             g=escape(_("Classic")))
    _write(target + name + ".nfo", nfo)
    return True


def _managed_dirs():
    """Pastas criadas pelo addon (têm um .strm apontando para o Sinexflix)."""
    found = {}
    base = folder()
    if not xbmcvfs.exists(base):
        return found
    dirs, _files = xbmcvfs.listdir(base)
    for d in dirs:
        sub = _join(base, d)
        _d, files = xbmcvfs.listdir(sub)
        for f in files:
            if f.endswith(".strm"):
                fh = xbmcvfs.File(sub + f)
                try:
                    content = fh.read()
                finally:
                    fh.close()
                if content.startswith(MARKER):
                    found[d] = sub
    return found


def _remove_dir(path):
    _d, files = xbmcvfs.listdir(path)
    for f in files:
        xbmcvfs.delete(path + f)
    xbmcvfs.rmdir(path)


def sync_all(silent=False):
    from . import storage
    wanted = {_movie_dir(e): e for e in storage.load_list() if e.get("kind") == "ia"}
    existing = _managed_dirs()
    added = removed = 0
    for name, entry in wanted.items():
        if name not in existing and export(entry):
            added += 1
    for name, path in existing.items():
        if name not in wanted:
            _remove_dir(path)
            removed += 1
    _scan()
    if not silent:
        notify(_("Library: {} added, {} removed").format(added, removed))
    return added, removed


def on_added(entry):
    if not enabled() or entry.get("kind") != "ia":
        return
    try:
        export(entry)
        _scan()
        first_time_help()
    except Exception as exc:
        log("Biblioteca: falha ao exportar ({})".format(exc))


def on_removed(entry):
    if not enabled() or entry.get("kind") != "ia":
        return
    path = _join(folder(), _movie_dir(entry))
    if xbmcvfs.exists(path):
        _remove_dir(path)


def first_time_help(force=False):
    if not force and read_json_file(HELP_FLAG, {}).get("shown"):
        return
    write_json_file(HELP_FLAG, {"shown": True})
    text = "\n".join([
        _("Classic films from My List are saved as library files in this folder:"),
        "",
        "[B]{}[/B]".format(xbmcvfs.translatePath(folder())),
        "",
        _("To see them in the Kodi Movies library (only once):"),
        _("1. Go to Settings > Media > Library > Videos > Add videos"),
        _("2. Browse to the folder above and confirm"),
        _("3. Set 'This directory contains' to Movies"),
        _("4. Choose the 'Local information only' information provider"),
        "",
        _("After that, every classic you add to My List appears in the library on its own."),
    ])
    xbmcgui.Dialog().textviewer(_("Kodi library"), text)
