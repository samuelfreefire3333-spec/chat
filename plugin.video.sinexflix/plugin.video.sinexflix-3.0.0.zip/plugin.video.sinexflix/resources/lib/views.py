# -*- coding: utf-8 -*-
"""Telas do addon (cada função monta uma pasta ou executa uma ação)."""

import random
import time

import xbmc
import xbmcgui
import xbmcplugin

from . import archive, cinemeta, kids, library, live, storage, tmdb, upcoming
from .common import (ADDON, ADDON_NAME, HANDLE, KODI_MAJOR, _, add_action, add_folder,
                     add_playable, build_url, end_dir, first, has_addon, human_size, log,
                     make_item, notify, resolve_failed, setting_bool, short_date, strip_html)


def colored(text, color):
    return "[COLOR {}]{}[/COLOR]".format(color, text)


def grey(text):
    return colored(text, "grey")


# --------------------------------------------------------------------------
# Menus
# --------------------------------------------------------------------------
def main_menu():
    if kids.is_on():
        add_folder(colored(_("Kids movies"), "deepskyblue"), mode="movies_menu")
        add_folder(colored(_("Kids series"), "deepskyblue"), mode="series_menu")
        add_folder(colored(_("Classic cartoons (full)"), "deepskyblue"),
                   mode="ia_list", coll=kids.KIDS_COLLECTION)
        add_folder(colored(_("Kids live TV"), "deepskyblue"), mode="live")
        add_folder(_("Surprise me"), mode="random")
        add_folder(_("My List"), mode="my_list")
        add_folder(_("Search"), mode="search_menu")
        add_action(grey(_("Leave kids mode")), mode="kids_off")
        end_dir(category=ADDON_NAME + " Kids", cache=False)
        return
    add_folder(_("Movies"), mode="movies_menu")
    add_folder(_("Series"), mode="series_menu")
    add_folder(_("Public archive: free full movies"), mode="ia_menu")
    add_folder(_("Live TV: free-to-air channels"), mode="live_menu")
    add_folder(_("Surprise me"), mode="random")
    if storage.load_watched():
        add_folder(_("Recently watched"), mode="watched")
    if any(i.get("kind") == "series" for i in storage.load_list()):
        add_folder(_("Upcoming episodes from My List"), mode="upcoming")
    if ADDON.getSetting("local_path"):
        add_folder(_("My local library"), mode="local")
    add_folder(_("My List"), mode="my_list")
    add_folder(_("Search"), mode="search_menu")
    add_folder(_("Tools"), mode="tools")
    end_dir(category=ADDON_NAME, cache=False)


def type_menu(mtype):
    if kids.is_on():
        for g in kids.KIDS_GENRES:
            label = cinemeta.genre_label(g)
            add_folder(_("{}: popular").format(label), mode="catalog", type=mtype, cid="top", genre=g)
            add_folder(_("{}: top rated").format(label), mode="catalog", type=mtype,
                       cid="imdbRating", genre=g)
        end_dir(category=_("Kids"))
        return
    add_folder(_("Popular"), mode="catalog", type=mtype, cid="top")
    add_folder(_("Top rated"), mode="catalog", type=mtype, cid="imdbRating")
    add_folder(_("By year"), mode="years", type=mtype)
    add_folder(_("By genre"), mode="genres", type=mtype)
    end_dir(category=_("Movies") if mtype == "movie" else _("Series"))


def list_genres(mtype):
    genres = cinemeta.MOVIE_GENRES if mtype == "movie" else cinemeta.SERIES_GENRES
    for g in sorted(genres, key=cinemeta.genre_label):
        add_folder(cinemeta.genre_label(g), mode="catalog", type=mtype, cid="top", genre=g)
    end_dir(category=_("Genres"))


def list_years(mtype):
    last = time.localtime().tm_year
    oldest = 1920 if mtype == "movie" else 1960
    for y in range(last, oldest - 1, -1):
        add_folder(str(y), mode="catalog", type=mtype, cid="year", genre=str(y))
    end_dir(category=_("By year"))


def tools_menu():
    add_action(_("Settings"), mode="settings")
    add_action(_("Where to watch: how to get the free key"), mode="tmdb_help")
    add_action(_("Where to watch: test my key"), mode="tmdb_test")
    add_action(_("Live TV: check all channels now"), mode="live_check")
    add_action(_("Kodi library: sync classics from My List"), mode="library_sync")
    add_action(_("Kodi library: how to set it up"), mode="library_help")
    add_action(_("Turn on kids mode"), mode="kids_on")
    if kids.has_pin():
        add_action(_("Change kids mode password"), mode="kids_pin")
    add_action(_("Clear cache"), mode="clear_cache")
    add_action(_("Clear search history"), mode="clear_history")
    add_action(_("Clear recently watched"), mode="clear_watched")
    if not has_addon(cinemeta.YT_PLUGIN):
        add_action(_("Install the YouTube add-on (for trailers)"), mode="install_yt")
    end_dir(category=_("Tools"), cache=False)


# --------------------------------------------------------------------------
# Catálogo (Cinemeta)
# --------------------------------------------------------------------------
def list_context(kind, ident, name, poster="", fanart="", year=""):
    label = _("Remove from My List") if storage.in_list(kind, ident) else _("Add to My List")
    url = build_url(mode="list_toggle", kind=kind, id=ident, name=name,
                    poster=poster, fanart=fanart, year=year)
    return [(label, "RunPlugin({})".format(url))]


def add_title(it, prefix=""):
    if not kids.allowed(it.get("genres")):
        return False
    mtype = it["type"]
    ctx = list_context(mtype, it["imdb"], it["name"], it["art"].get("poster", ""),
                       it["art"].get("fanart", ""), it["year"])
    ctx.insert(0, (_("Watch trailer"), "RunPlugin({})".format(
        build_url(mode="trailer", type=mtype, imdb=it["imdb"]))))
    if tmdb.api_key():
        ctx.insert(1, (_("Where to watch"), "Container.Update({})".format(
            build_url(mode="providers", type=mtype, imdb=it["imdb"], name=it["name"]))))
    add_folder(prefix + it["label"], art=it["art"], info=it["info"], context=ctx,
               mode="title", type=mtype, imdb=it["imdb"])
    return True


def list_catalog(mtype, cid="top", genre=None, skip=0):
    if kids.is_on() and genre not in kids.KIDS_GENRES:
        genre = "Animation"
    items = cinemeta.catalog(mtype, cid, genre, skip=skip)
    for it in items:
        add_title(it)
    if len(items) >= 20:
        add_folder("[B]{} >>[/B]".format(_("Next page")), mode="catalog", type=mtype, cid=cid,
                   genre=genre, skip=skip + len(items))
    if not items:
        notify(_("Nothing found here"))
    category = cinemeta.genre_label(genre) if genre and not genre.isdigit() else genre
    end_dir("movies" if mtype == "movie" else "tvshows", category=category, sort=True)


def play_trailer(mtype, imdb):
    if not has_addon(cinemeta.YT_PLUGIN):
        xbmc.executebuiltin("InstallAddon({})".format(cinemeta.YT_PLUGIN))
        return
    ids = cinemeta.trailer_ids(cinemeta.get_meta(mtype, imdb))
    if not ids:
        notify(_("This title has no trailer"))
        return
    xbmc.executebuiltin("PlayMedia({})".format(cinemeta.youtube_url(ids[0][1])))


def title_page(mtype, imdb):
    meta = cinemeta.get_meta(mtype, imdb)
    it = cinemeta.meta_to_item(meta, mtype) if meta else None
    if not it:
        notify(_("Could not load this title"))
        end_dir()
        return
    if not kids.allowed(it.get("genres")):
        notify(_("Not available in kids mode"))
        end_dir()
        return
    art, info = it["art"], dict(it["info"])

    # Onde assistir
    if tmdb.api_key():
        try:
            result = tmdb.providers(mtype, imdb)
            text = tmdb.summary(result) if result else ""
            if text:
                label = "[B]{}[/B] {}".format(_("Where to watch:"), colored(text, "limegreen"))
            else:
                label = _("Where to watch: not available on streaming in your country")
            add_folder(label, art=art, info=info, mode="providers", type=mtype, imdb=imdb,
                       name=it["name"])
        except Exception as exc:
            log("TMDB falhou: {}".format(exc))
            add_action(grey(_("Where to watch: could not check now")), art=art, info=info,
                       mode="noop")
    elif not kids.is_on():
        add_action(grey(_("Where to watch (set up the free key)")), art=art, info=info,
                   mode="tmdb_help")

    # Trailers
    trailers = cinemeta.trailer_ids(meta)
    if trailers and has_addon(cinemeta.YT_PLUGIN):
        for n, (title, vid) in enumerate(trailers[:3], 1):
            lbl = "[B]▶ {}[/B]".format(_("Watch trailer")) if n == 1 else "▶ {} {}".format(title, n)
            add_playable(lbl, cinemeta.youtube_url(vid), art, info)
    elif trailers:
        add_action("▶ " + _("Trailer (install the YouTube add-on)"), art=art, info=info,
                   mode="install_yt")

    # Temporadas
    if mtype == "series":
        videos = meta.get("videos") or []
        seasons = sorted({v.get("season") for v in videos if v.get("season") is not None})
        if not setting_bool("show_specials"):
            seasons = [s for s in seasons if s != 0]
        for s in seasons:
            count = sum(1 for v in videos if v.get("season") == s)
            label = _("Specials") if s == 0 else _("Season {}").format(s)
            sinfo = dict(info, mediatype="season", season=s, title=label)
            add_folder("{}  {}".format(label, grey(_("({} episodes)").format(count))),
                       art=art, info=sinfo, mode="season", imdb=imdb, season=s)

    # Acervo público (só faz sentido para filmes antigos)
    if mtype == "movie" and info.get("year", 9999) <= 1980:
        add_folder(_("Look for the full movie in the public archive"), art=art, info=info,
                   mode="ia_list", q=it["name"], year=it["year"])

    lbl = _("Remove from My List") if storage.in_list(mtype, imdb) else _("Add to My List")
    add_action(lbl, art=art, info=info, mode="list_toggle", kind=mtype, id=imdb,
               name=it["name"], poster=art.get("poster", ""), fanart=art.get("fanart", ""),
               year=it["year"])
    end_dir("movies" if mtype == "movie" else "tvshows", category=it["name"], cache=False)


def providers_page(mtype, imdb, name=""):
    result = tmdb.providers(mtype, imdb)
    if result is None:
        tmdb.show_setup_help()
        end_dir()
        return
    if not result["groups"]:
        add_action(_("Not available on any streaming service in your country right now."),
                   mode="noop")
    for cat, items in result["groups"]:
        cat_label = tmdb.category_label(cat)
        color = "limegreen" if cat in ("free", "ads") else ("white" if cat == "flatrate" else "grey")
        for p in items:
            pname = p.get("provider_name", "?")
            label = "{}  {}".format(pname, colored("· " + cat_label, color))
            logo = tmdb.logo_url(p)
            add_action(label, art={"thumb": logo, "icon": logo},
                       info={"title": pname, "plot": _("Availability data provided by JustWatch.")},
                       mode="provider_open", pname=pname, title=name, cat=cat,
                       link=result.get("link", ""))
    end_dir("files", category=_("Where to watch") + (": " + name if name else ""))


def list_season(imdb, season):
    meta = cinemeta.get_meta("series", imdb)
    show = meta.get("name", "")
    fanart = meta.get("background") or meta.get("poster") or ""
    today = time.strftime("%Y-%m-%d")
    hide_future = not setting_bool("show_upcoming")
    videos = [v for v in meta.get("videos") or [] if v.get("season") == int(season)]
    videos.sort(key=cinemeta.episode_number)
    for v in videos:
        ep = cinemeta.episode_number(v)
        released = cinemeta.release_date(v)
        future = bool(released) and released > today
        if future and hide_future:
            continue
        title = v.get("name") or v.get("title") or _("Episode {}").format(ep)
        label = "{}x{:02d}. {}".format(season, ep, title)
        if future:
            label += "  " + colored(_("(premieres {})").format(short_date(released)), "orange")
        info = {
            "title": title, "tvshowtitle": show, "season": int(season), "episode": ep,
            "plot": v.get("overview") or v.get("description") or "",
            "premiered": released, "mediatype": "episode",
        }
        try:
            info["rating"] = float(v.get("rating") or 0)
        except ValueError:
            pass
        thumb = v.get("thumbnail") or meta.get("poster") or ""
        add_action(label, art={"thumb": thumb, "fanart": fanart}, info=info,
                   mode="noop" if future else "episode_play",
                   imdb=imdb, show=show, season=season, episode=ep, ep_title=title)
    end_dir("episodes", category="{} - {}".format(show, _("Season {}").format(season)))


# --------------------------------------------------------------------------
# Acervo público
# --------------------------------------------------------------------------
def ia_menu():
    add_folder(_("Most watched"), mode="ia_list", coll="feature_films", sort="downloads desc")
    add_folder(_("Recently added"), mode="ia_list", coll="feature_films", sort="addeddate desc")
    for label, coll in archive.collections():
        add_folder(label, mode="ia_list", coll=coll)
    add_folder(_("Search the archive"), mode="search_menu", scope="ia")
    end_dir(category=_("Public archive"))


def add_ia_item(it):
    ctx = list_context("ia", it["id"], it["title"], it["art"]["poster"], "", it["year"])
    add_playable(it["label"], build_url(mode="ia_play", id=it["id"]), it["art"], it["info"], ctx)


def ia_list(q=None, coll=None, year=None, sort=None, page=1):
    docs, total = archive.query(q, coll, year, sort, page)
    if not docs and year:
        docs, total = archive.query(q, coll, None, sort, page)
    items = [x for x in (archive.doc_to_item(d) for d in docs) if x]
    for it in items:
        add_ia_item(it)
    rows = archive.rows()
    if page * rows < total:
        add_folder("[B]{} >>[/B]  {}".format(_("Next page"), grey("({}/{})".format(
            min(page * rows, total), total))),
            mode="ia_list", q=q, coll=coll, year=year, sort=sort, page=page + 1)
    if not items:
        notify(_("Nothing found in the public archive"))
    end_dir("movies", category=_("Public archive"), sort=True)


def ia_play(ident):
    meta = archive.metadata(ident)
    all_files = meta.get("files") or []
    files = archive.pick_files(all_files)
    if not files:
        notify(_("No playable video in this item"))
        resolve_failed()
        return
    chosen = files[0]
    if len(files) > 1:
        labels = ["{}  [{}]".format(f.get("title") or f.get("name"), human_size(f.get("size")))
                  for f in files]
        idx = xbmcgui.Dialog().select(_("Choose the part / file"), labels)
        if idx < 0:
            resolve_failed()
            return
        chosen = files[idx]
    md = meta.get("metadata", {})
    title = first(md.get("title")) or ident
    url = archive.file_url(ident, chosen["name"]) + "|User-Agent=Mozilla/5.0"
    li = make_item(title, {"title": title, "plot": strip_html(first(md.get("description"))),
                           "mediatype": "movie"},
                   {"poster": archive.IA_IMG + ident, "thumb": archive.IA_IMG + ident},
                   path=url, playable=True)
    subs = archive.subtitles(ident, all_files)
    if subs:
        li.setSubtitles(subs)
    xbmcplugin.setResolvedUrl(HANDLE, True, li)
    storage.watched_add({"kind": "ia", "id": ident, "name": title,
                         "year": str(first(md.get("year")) or first(md.get("date")) or "")[:4],
                         "poster": archive.IA_IMG + ident})


def ia_random():
    for d in archive.random_docs():
        it = archive.doc_to_item(d)
        if it:
            add_ia_item(it)
    add_folder("[B]{}[/B]".format(_("Shuffle again")), mode="random",
               seed=random.randint(1, 10 ** 6))
    end_dir("movies", category=_("Surprise me"), cache=False)


# --------------------------------------------------------------------------
# Assistidos e próximos episódios
# --------------------------------------------------------------------------
def episode_play(imdb, show, season, episode, ep_title=""):
    q = "{} {}".format(show, ep_title).strip()
    docs, _total = archive.query(q=q, coll=" OR ".join(archive.TV_COLLECTIONS), nrows=10)
    if docs:
        ident = docs[0].get("identifier")
        if ident:
            ia_play(ident)
            return
    if tmdb.api_key():
        xbmc.executebuiltin("Container.Update({})".format(
            build_url(mode="providers", type="series", imdb=imdb, name=show)))
    else:
        xbmc.executebuiltin("Container.Update({})".format(
            build_url(mode="ia_list", q=show)))


def watched_list():
    for i in storage.load_watched():
        kind = i.get("kind", "ia")
        art = {"poster": i.get("poster"), "thumb": i.get("poster")}
        label = "{} ({})".format(i["name"], i["year"]) if i.get("year") else i["name"]
        label += "  " + grey(short_date(time.strftime("%Y-%m-%d", time.localtime(i.get("when", 0)))))
        if kind in ("movie", "series"):
            add_folder(label, art=art, info={"title": i["name"], "mediatype": "tvshow" if kind == "series" else "movie"},
                       mode="title", type=kind, imdb=i["id"])
        else:
            mode = "ia_play" if kind == "ia" else "live_play"
            add_playable(label, build_url(mode=mode, id=i["id"]), art,
                         {"title": i["name"], "mediatype": "movie" if mode == "ia_play" else "video"})
    end_dir("movies", category=_("Recently watched"), cache=False)


def friendly_date(iso):
    today = time.strftime("%Y-%m-%d")
    tomorrow = time.strftime("%Y-%m-%d", time.localtime(time.time() + 86400))
    yesterday = time.strftime("%Y-%m-%d", time.localtime(time.time() - 86400))
    if iso == today:
        return colored(_("Today"), "limegreen")
    if iso == tomorrow:
        return colored(_("Tomorrow"), "yellow")
    if iso == yesterday:
        return _("Yesterday")
    return short_date(iso)


def upcoming_list():
    eps = upcoming.collect()
    if not eps:
        add_action(_("No episodes between 7 days ago and the next 30 days."), mode="noop")
    for rel, show, meta, v in eps:
        ep = cinemeta.episode_number(v)
        label = "{}  {}  {}x{:02d}  {}".format(friendly_date(rel), meta.get("name", show["name"]),
                                                v["season"], ep, v.get("name") or "")
        info = {"title": v.get("name") or "", "tvshowtitle": meta.get("name"),
                "season": v["season"], "episode": ep, "premiered": rel,
                "plot": v.get("overview") or v.get("description") or "", "mediatype": "episode"}
        art = {"thumb": v.get("thumbnail") or meta.get("poster"),
               "fanart": meta.get("background"), "poster": meta.get("poster")}
        add_folder(label, art=art, info=info, mode="season", imdb=show["id"], season=v["season"])
    end_dir("episodes", category=_("Upcoming episodes"), cache=False)


# --------------------------------------------------------------------------
# TV ao vivo
# --------------------------------------------------------------------------
def live_menu():
    channels = live.load_channels()
    if not channels:
        notify(_("Channel list unavailable right now"))
        end_dir()
        return
    status = live.load_status()
    hide = setting_bool("live_hide_offline")
    visible = [c for c in channels if not (hide and live.channel_state(status, c) is False)]
    counts = {}
    for c in visible:
        for g in c["groups"]:
            counts[g] = counts.get(g, 0) + 1
    age = live.last_check_age()
    if age is None:
        check_label = _("Check which channels are online")
    else:
        check_label = _("Check channels again (last check {} h ago)").format(int(age // 3600))
    add_action(grey(check_label), mode="live_check")
    add_folder("[B]{}[/B]  {}".format(_("All channels"), grey("({})".format(len(visible)))),
               mode="live")
    for g in sorted(counts, key=live.group_label):
        add_folder("{}  {}".format(live.group_label(g), grey("({})".format(counts[g]))),
                   mode="live", group=g)
    end_dir(category=_("Live TV"), cache=False)


def live_list(group=None):
    channels = live.load_channels()
    if group:
        channels = [c for c in channels if group in c["groups"]]
    status = live.load_status()
    hide = setting_bool("live_hide_offline")
    shown = 0
    for c in channels:
        state = live.channel_state(status, c)
        if hide and state is False:
            continue
        name = live.clean_name(c["name"])
        dot = colored("●", "limegreen") if state else (colored("●", "red") if state is False else grey("○"))
        extra = ""
        if "not 24/7" in c["name"].lower():
            extra += "  " + grey(_("(part-time)"))
        if c["alts"]:
            extra += "  " + grey(_("+{} source(s)").format(len(c["alts"])))
        plot = ", ".join(live.group_label(g) for g in c["groups"])
        art = {"thumb": c["logo"], "icon": c["logo"] or "DefaultTVShows.png"}
        add_playable("{} {}{}".format(dot, name, extra), build_url(mode="live_play", id=c["id"]),
                     art, {"title": name, "plot": plot, "mediatype": "video"})
        shown += 1
    if not shown:
        add_action(_("No channels in this category right now."), mode="noop")
    end_dir("videos", category=live.group_label(group) if group else _("All channels"), cache=False)


def live_check():
    channels = live.load_channels()
    dlg = xbmcgui.DialogProgress()
    dlg.create(_("Live TV"), _("Checking channels..."))

    def progress(done, total):
        dlg.update(int(done * 100 / max(total, 1)), _("Checked {} of {} sources").format(done, total))
        return not dlg.iscanceled()

    try:
        ok, done = live.check_all(channels, progress)
    finally:
        dlg.close()
    notify(_("{} of {} sources online").format(ok, done))
    xbmc.executebuiltin("Container.Refresh")


def live_play(ident):
    chan = live.find(ident)
    if not chan:
        notify(_("Channel not found"))
        resolve_failed()
        return
    options = live.sources(chan)
    if len(options) > 1 and setting_bool("live_ask_source"):
        idx = xbmcgui.Dialog().select(_("Choose the source"), [
            _("Source {}: {}").format(n + 1, o["name"]) for n, o in enumerate(options)])
        if idx < 0:
            resolve_failed()
            return
        src = options[idx]
    else:
        src = live.pick_working_source(chan)
        if not src:
            notify(_("This channel is offline right now"))
            resolve_failed()
            return
    name = live.clean_name(chan["name"])
    li = make_item(name, {"title": name, "mediatype": "video"}, {"thumb": chan["logo"]},
                   path=live.play_url(src), playable=True)
    if ".m3u8" in src["url"] and has_addon("inputstream.adaptive"):
        li.setProperty("inputstream", "inputstream.adaptive")
        if KODI_MAJOR < 21:
            li.setProperty("inputstream.adaptive.manifest_type", "hls")
        li.setMimeType("application/vnd.apple.mpegurl")
        li.setContentLookup(False)
    xbmcplugin.setResolvedUrl(HANDLE, True, li)
    storage.watched_add({"kind": "live", "id": ident, "name": name, "year": "", "poster": chan["logo"]})


# --------------------------------------------------------------------------
# Minha Lista
# --------------------------------------------------------------------------
def my_list():
    items = storage.visible_list()
    if not items:
        add_action(_("Your list is empty. Use the context menu to add titles."), mode="noop")
    tags = {"movie": _("Movie"), "series": _("Show"), "ia": _("Archive")}
    for i in items:
        kind = i.get("kind")
        art = {"poster": i.get("poster"), "thumb": i.get("poster"), "fanart": i.get("fanart")}
        label = "{} ({})".format(i["name"], i["year"]) if i.get("year") else i["name"]
        label = "{} {}".format(grey("[{}]".format(tags.get(kind, ""))), label)
        ctx = list_context(kind, i["id"], i["name"], i.get("poster", ""),
                           i.get("fanart", ""), i.get("year", ""))
        info = {"title": i["name"], "mediatype": "tvshow" if kind == "series" else "movie"}
        if kind == "ia":
            add_playable(label, build_url(mode="ia_play", id=i["id"]), art, info, ctx)
        else:
            add_folder(label, art=art, info=info, context=ctx, mode="title", type=kind, imdb=i["id"])
    end_dir("movies", category=_("My List"), cache=False)


# --------------------------------------------------------------------------
# Busca
# --------------------------------------------------------------------------
def search_menu(scope=None):
    add_folder("[B]{}[/B]".format(_("New search...")), mode="search_new", scope=scope)
    for q in storage.load_history():
        url = build_url(mode="history_remove", q=q)
        add_folder(q, art={"thumb": "DefaultAddonsSearch.png"},
                   context=[(_("Remove from history"), "RunPlugin({})".format(url))],
                   mode="search_results", q=q, scope=scope)
    end_dir(category=_("Search"), cache=False)


def search_new(scope=None):
    query = xbmcgui.Dialog().input(_("Search movies, series and the public archive"))
    xbmcplugin.endOfDirectory(HANDLE, succeeded=False)
    if not query or not query.strip():
        return
    storage.history_add(query.strip())
    xbmc.executebuiltin("Container.Update({})".format(
        build_url(mode="search_results", q=query.strip(), scope=scope)))


def search_results(query, scope=None):
    found = 0
    if scope != "ia":
        for mtype, tag in (("movie", _("Movie")), ("series", _("Show"))):
            try:
                for it in cinemeta.catalog(mtype, "top", search=query):
                    if add_title(it, grey("[{}] ".format(tag))):
                        found += 1
            except Exception as exc:
                log("Busca {} falhou: {}".format(mtype, exc))
    try:
        docs, _total = archive.query(q=query)
        for d in docs[:30]:
            it = archive.doc_to_item(d)
            if it:
                it["label"] = colored("[{}]".format(_("Archive")), "limegreen") + " " + it["label"]
                add_ia_item(it)
                found += 1
    except Exception as exc:
        log("Busca no acervo falhou: {}".format(exc))
    if not found:
        notify(_("Nothing found for \"{}\"").format(query))
    end_dir("movies", category=_("Search: {}").format(query))


# --------------------------------------------------------------------------
# Ações de ferramentas
# --------------------------------------------------------------------------
def tmdb_test():
    ok, msg = tmdb.test_key()
    if not ok and not tmdb.api_key():
        tmdb.show_setup_help()
        return
    notify(msg)


def library_sync():
    if not library.enabled():
        if not xbmcgui.Dialog().yesno(_("Kodi library"),
                                      _("Library sync is off in the settings. Sync once anyway?")):
            return
    library.sync_all()
    library.first_time_help()
