# -*- coding: utf-8 -*-
"""Minha Lista, assistidos recentemente e histórico de buscas."""

import os
import time

from . import kids
from .common import PROFILE, _, notify, read_json_file, refresh, write_json_file

LIST_FILE = os.path.join(PROFILE, "minha_lista.json")
WATCHED_FILE = os.path.join(PROFILE, "assistidos.json")
HISTORY_FILE = os.path.join(PROFILE, "buscas.json")


# --------------------------------------------------------------------------
# Minha Lista
# --------------------------------------------------------------------------
def load_list():
    return read_json_file(LIST_FILE, [])


def visible_list():
    """No modo infantil só aparece o que foi adicionado no modo infantil."""
    items = load_list()
    if kids.is_on():
        items = [i for i in items if i.get("kids")]
    return items


def in_list(kind, ident):
    return any(i.get("kind") == kind and i.get("id") == ident for i in load_list())


def toggle(kind, ident, name, poster="", fanart="", year=""):
    from . import library   # import tardio para evitar ciclo
    items = load_list()
    exists = [i for i in items if i.get("kind") == kind and i.get("id") == ident]
    if exists:
        items = [i for i in items if i not in exists]
        write_json_file(LIST_FILE, items)
        notify(_("Removed from My List"))
        for entry in exists:
            library.on_removed(entry)
    else:
        entry = {"kind": kind, "id": ident, "name": name, "poster": poster,
                 "fanart": fanart, "year": year, "kids": kids.is_on(),
                 "added": int(time.time())}
        items.insert(0, entry)
        write_json_file(LIST_FILE, items)
        notify(_("Added to My List"))
        library.on_added(entry)
    refresh()


# --------------------------------------------------------------------------
# Assistidos recentemente
# --------------------------------------------------------------------------
def load_watched():
    items = read_json_file(WATCHED_FILE, [])
    if kids.is_on():
        items = [i for i in items if i.get("kids")]
    return items


def watched_add(entry):
    items = [i for i in read_json_file(WATCHED_FILE, [])
             if not (i.get("kind") == entry["kind"] and i.get("id") == entry["id"])]
    entry["when"] = int(time.time())
    entry["kids"] = kids.is_on()
    items.insert(0, entry)
    try:
        write_json_file(WATCHED_FILE, items[:50])
    except OSError:
        pass


def clear_watched():
    write_json_file(WATCHED_FILE, [])
    notify(_("Recently watched cleared"))
    refresh()


# --------------------------------------------------------------------------
# Histórico de buscas
# --------------------------------------------------------------------------
def load_history():
    return read_json_file(HISTORY_FILE, [])


def history_add(query):
    hist = [q for q in load_history() if q.lower() != query.lower()]
    hist.insert(0, query)
    write_json_file(HISTORY_FILE, hist[:15])


def history_remove(query):
    write_json_file(HISTORY_FILE, [q for q in load_history() if q != query])
    refresh()


def clear_history():
    write_json_file(HISTORY_FILE, [])
    notify(_("Search history cleared"))
