# -*- coding: utf-8 -*-
"""
Modo infantil.

O estado fica num arquivo próprio (kids.json) e NÃO nas configurações do
addon, para que ninguém consiga desligá-lo pela tela de configurações do
Kodi. A senha é guardada só como hash (SHA-256 com sal).
"""

import hashlib
import os
import secrets

import xbmcgui

from .common import (ADDON, PROFILE, _, notify, read_json_file, write_json_file)

STATE_FILE = os.path.join(PROFILE, "kids.json")
KIDS_GENRES = ("Animation", "Family")
KIDS_COLLECTION = "animationandcartoons"
KIDS_LIVE_GROUPS = ("Kids", "Animation", "Family")

_state = None


def _load():
    global _state
    if _state is None:
        _state = read_json_file(STATE_FILE, {})
        _migrate_old_settings()
    return _state


def _migrate_old_settings():
    """Versões antigas guardavam o modo infantil nas configurações."""
    if ADDON.getSetting("kids_mode") == "true" and not _state.get("enabled"):
        _state["enabled"] = True
        old_pin = ADDON.getSetting("kids_pin").strip()
        if old_pin:
            _state.update(_hash(old_pin))
        _save()
    if ADDON.getSetting("kids_mode") or ADDON.getSetting("kids_pin"):
        try:
            ADDON.setSetting("kids_mode", "")
            ADDON.setSetting("kids_pin", "")
        except Exception:
            pass


def _save():
    write_json_file(STATE_FILE, _state)


def _hash(pin, salt=None):
    salt = salt or secrets.token_hex(8)
    digest = hashlib.sha256((salt + pin).encode("utf-8")).hexdigest()
    return {"salt": salt, "pin": digest}


def is_on():
    return bool(_load().get("enabled"))


def has_pin():
    return bool(_load().get("pin"))


def check_pin(typed):
    st = _load()
    if not st.get("pin"):
        return True
    return _hash(typed or "", st.get("salt"))["pin"] == st["pin"]


def unlock():
    """Pede a senha quando o modo infantil está ligado. True = liberado."""
    if not is_on() or not has_pin():
        return True
    typed = xbmcgui.Dialog().numeric(0, _("Kids mode password"))
    if typed and check_pin(typed):
        return True
    notify(_("Wrong password"))
    return False


def enable():
    st = _load()
    if not st.get("pin"):
        dlg = xbmcgui.Dialog()
        if dlg.yesno(_("Kids mode"), _("Create a password to leave kids mode?")):
            pin = dlg.numeric(0, _("Create a numeric password"))
            if pin:
                again = dlg.numeric(0, _("Type the password again"))
                if again != pin:
                    notify(_("Passwords do not match. Kids mode was not turned on."))
                    return False
                st.update(_hash(pin))
    st["enabled"] = True
    _save()
    notify(_("Kids mode on"))
    return True


def disable():
    if not unlock():
        return False
    st = _load()
    st["enabled"] = False
    _save()
    notify(_("Kids mode off"))
    return True


def change_pin():
    if not unlock():
        return
    dlg = xbmcgui.Dialog()
    pin = dlg.numeric(0, _("New password (empty = no password)"))
    st = _load()
    if not pin:
        st.pop("pin", None)
        st.pop("salt", None)
        notify(_("Password removed"))
    else:
        if dlg.numeric(0, _("Type the password again")) != pin:
            notify(_("Passwords do not match"))
            return
        st.update(_hash(pin))
        notify(_("Password changed"))
    _save()


def allowed(genres):
    """No modo infantil, só passam títulos de animação ou família."""
    if not is_on():
        return True
    return any(g in KIDS_GENRES for g in (genres or []))
