# -*- coding: utf-8 -*-
"""
"Onde assistir": em quais serviços um título está disponível no país.
Fonte: API grátis do TMDB (dados de disponibilidade fornecidos pela JustWatch).
Aceita tanto a "Chave da API" (v3) quanto o "Token de leitura" (v4).
"""

import urllib.parse

import xbmc
import xbmcgui

from .common import _, has_addon, http_json, log, setting

API = "https://api.themoviedb.org/3"
LOGO = "https://image.tmdb.org/t/p/w300"
SIGNUP_URL = "https://www.themoviedb.org/settings/api"

CATEGORIES = ("free", "ads", "flatrate", "rent", "buy")

# Serviços que têm addon para Kodi: se estiver instalado, oferecemos abrir.
KODI_ADDONS = (
    ("netflix", "plugin.video.netflix"),
    ("amazon prime video", "plugin.video.amazon-test"),
    ("disney plus", "slyguy.disney.plus"),
    ("youtube", "plugin.video.youtube"),
    ("crunchyroll", "plugin.video.crunchyroll"),
)


def category_label(cat):
    return {
        "free": _("Free"),
        "ads": _("Free with ads"),
        "flatrate": _("Subscription"),
        "rent": _("Rent"),
        "buy": _("Buy"),
    }.get(cat, cat)


def api_key():
    return (setting("tmdb_key") or "").strip()


def region():
    return (setting("tmdb_region") or "BR").strip().upper() or "BR"


def _get(path, ttl, **params):
    key = api_key()
    headers = {"Accept": "application/json"}
    if key.startswith("eyJ"):            # token de leitura (v4)
        headers["Authorization"] = "Bearer " + key
    else:                                # chave da API (v3)
        params["api_key"] = key
    url = API + path
    if params:
        url += "?" + urllib.parse.urlencode(params)
    return http_json(url, ttl=ttl, headers=headers)


def test_key():
    if not api_key():
        return False, _("No key configured")
    try:
        _get("/configuration", ttl=0)
        return True, _("Key working!")
    except Exception as exc:
        log("TMDB: chave recusada ({})".format(exc))
        return False, _("The key was rejected. Check that you copied it whole.")


def tmdb_id(mtype, imdb):
    data = _get("/find/" + imdb, ttl=30 * 86400, external_source="imdb_id")
    results = data.get("movie_results" if mtype == "movie" else "tv_results") or []
    return results[0]["id"] if results else None


def providers(mtype, imdb):
    """Retorna {"link": url, "groups": [(categoria, [provedor, ...]), ...]} ou None."""
    if not api_key():
        return None
    tid = tmdb_id(mtype, imdb)
    if not tid:
        return {"link": "", "groups": []}
    kind = "movie" if mtype == "movie" else "tv"
    data = _get("/{}/{}/watch/providers".format(kind, tid), ttl=24 * 3600)
    country = (data.get("results") or {}).get(region()) or {}
    groups = []
    for cat in CATEGORIES:
        items = sorted(country.get(cat) or [], key=lambda p: p.get("display_priority", 99))
        if items:
            groups.append((cat, items))
    return {"link": country.get("link", ""), "groups": groups}


def summary(result, limit=3):
    """Texto curto: 'Netflix, Globoplay +2'. Prioriza os grátis e por assinatura."""
    names = []
    for cat, items in result.get("groups", []):
        if cat in ("rent", "buy") and names:
            continue
        for p in items:
            n = p.get("provider_name")
            if n and n not in names:
                names.append(n)
    if not names:
        return ""
    text = ", ".join(names[:limit])
    if len(names) > limit:
        text += " +{}".format(len(names) - limit)
    return text


def logo_url(provider):
    return LOGO + provider["logo_path"] if provider.get("logo_path") else ""


def kodi_addon_for(name):
    low = (name or "").lower()
    for key, addon_id in KODI_ADDONS:
        if key in low:
            return addon_id
    return None


def open_provider(name, title, category, link=""):
    addon_id = kodi_addon_for(name)
    dlg = xbmcgui.Dialog()
    if addon_id and has_addon(addon_id):
        if dlg.yesno(name, _("Open the {} add-on to look for \"{}\"?").format(name, title)):
            xbmc.executebuiltin("ActivateWindow(Videos,plugin://{}/,return)".format(addon_id))
        return
    text = _("\"{}\" is available on [B]{}[/B] ({}).").format(title, name, category_label(category).lower())
    text += "\n\n" + _("Open the {} app on your TV, phone or computer and search for the title.").format(name)
    if link:
        text += "\n\n" + _("More details: {}").format(link)
    text += "\n\n[I]" + _("Availability data provided by JustWatch.") + "[/I]"
    dlg.ok(_("Where to watch"), text)


def show_setup_help():
    steps = "\n".join([
        _("1. On your phone or computer, create a free account at themoviedb.org"),
        _("2. Go to Settings > API and request a key (choose 'Developer', personal use)"),
        _("3. Copy the 'API Key' (or the 'API Read Access Token')"),
        _("4. Paste it in Sinexflix settings > Where to watch"),
    ])
    xbmcgui.Dialog().textviewer(_("Set up 'Where to watch' (free)"),
                                steps + "\n\n" + SIGNUP_URL)
