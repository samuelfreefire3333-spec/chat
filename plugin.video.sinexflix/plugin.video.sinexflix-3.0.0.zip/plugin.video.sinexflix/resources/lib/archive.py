# -*- coding: utf-8 -*-
"""Acervo público do Internet Archive (filmes em domínio público)."""

import random
import re
import urllib.parse

from . import kids
from .common import _, first, http_json, setting_int, strip_html

IA_SEARCH = "https://archive.org/advancedsearch.php"
IA_META = "https://archive.org/metadata/"
IA_DOWNLOAD = "https://archive.org/download/"
IA_IMG = "https://archive.org/services/img/"

VIDEO_EXT = (".mp4", ".mkv", ".avi", ".mov", ".m4v", ".wmv", ".mpg", ".mpeg",
             ".ts", ".m2ts", ".webm", ".ogv", ".flv", ".3gp")


def collections():
    return [
        (_("Classic films"), "feature_films"),
        (_("Film noir"), "Film_Noir"),
        (_("Sci-fi and horror"), "SciFi_Horror"),
        (_("Comedies"), "Comedy_Films"),
        (_("Silent films"), "silent_films"),
        (_("Cartoons and animation"), "animationandcartoons"),
    ]


def rows():
    return max(10, setting_int("ia_rows", 50))


def query(q=None, coll=None, year=None, sort="downloads desc", page=1, nrows=None):
    parts = ["mediatype:(movies)"]
    if kids.is_on():
        coll = kids.KIDS_COLLECTION
    if coll:
        parts.append("collection:({})".format(coll))
    else:
        parts.append("collection:({})".format(" OR ".join(c for _x, c in collections())))
    if q:
        safe = re.sub(r'[\\"():\[\]{}^~*?!+\-]', " ", q).strip()
        parts.append('title:("{}")'.format(safe))
    if year and str(year).isdigit():
        y = int(year)
        parts.append("year:[{} TO {}]".format(y - 1, y + 1))
    params = [("q", " AND ".join(parts))]
    for f in ("identifier", "title", "year", "description", "runtime", "subject"):
        params.append(("fl[]", f))
    params += [("sort[]", sort or "downloads desc"), ("rows", str(nrows or rows())),
               ("page", str(page)), ("output", "json")]
    resp = http_json(IA_SEARCH + "?" + urllib.parse.urlencode(params)).get("response", {})
    return resp.get("docs", []) or [], int(resp.get("numFound") or 0)


def random_docs(count=15):
    coll = kids.KIDS_COLLECTION if kids.is_on() else "feature_films"
    _docs, total = query(coll=coll, page=1, nrows=1)
    per_page = 50
    page = random.randint(1, max(1, min(total, 5000) // per_page))
    docs, _t = query(coll=coll, page=page, nrows=per_page)
    random.shuffle(docs)
    return docs[:count]


def parse_runtime(text):
    text = str(first(text))
    m = re.match(r"(?:(\d+):)?(\d+):(\d+)$", text.strip())
    if m:
        h, mi, s = m.groups()
        return int(h or 0) * 3600 + int(mi) * 60 + int(s)
    m = re.search(r"(\d+)\s*min", text)
    return int(m.group(1)) * 60 if m else 0


def doc_to_item(d):
    ident = d.get("identifier")
    if not ident:
        return None
    title = first(d.get("title")) or ident
    year = str(first(d.get("year")) or "")[:4]
    img = IA_IMG + ident
    info = {"title": title, "plot": strip_html(first(d.get("description"))), "mediatype": "movie"}
    if year.isdigit():
        info["year"] = int(year)
    dur = parse_runtime(d.get("runtime"))
    if dur:
        info["duration"] = dur
    subj = d.get("subject")
    if subj:
        subj = subj if isinstance(subj, list) else [subj]
        info["genre"] = [s for s in subj if isinstance(s, str)][:3]
    label = "{} ({})".format(title, year) if year else title
    return {"id": ident, "title": title, "year": year, "label": label, "info": info,
            "art": {"poster": img, "thumb": img, "fanart": img}}


def pick_files(files):
    """Escolhe os arquivos de vídeo, preferindo MP4 de boa qualidade e evitando duplicatas."""
    videos = []
    for f in files:
        low = f.get("name", "").lower()
        fmt = (f.get("format") or "").lower()
        if not low.endswith(VIDEO_EXT) or "sample" in low or "trailer" in low:
            continue
        if any(x in fmt for x in ("thumb", "gif", "image", "torrent")):
            continue
        videos.append(f)

    def base(name):
        return re.sub(r"(\.ia)?(_512kb)?\.\w+$", "", name, flags=re.I).lower()

    def score(f):
        name = f.get("name", "").lower()
        fmt = (f.get("format") or "").lower()
        s = 0
        if name.endswith(".mp4"):
            s += 100
        if "h.264" in fmt or "mpeg4" in fmt:
            s += 20
        if "512kb" in name:
            s -= 30
        if name.endswith((".mkv", ".avi", ".mpg", ".mpeg")):
            s -= 10
        try:
            s += min(float(f.get("size") or 0) / 1e8, 15)
        except ValueError:
            pass
        return s

    best = {}
    for f in videos:
        b = base(f.get("name", ""))
        if b not in best or score(f) > score(best[b]):
            best[b] = f
    return sorted(best.values(), key=lambda f: f.get("name", "").lower())


def metadata(ident):
    return http_json(IA_META + urllib.parse.quote(ident), ttl=24 * 3600)


def file_url(ident, name):
    return IA_DOWNLOAD + urllib.parse.quote(ident) + "/" + urllib.parse.quote(name)


TV_COLLECTIONS = ("classic_tv", "television", "classic_cartoons")


def subtitles(ident, files):
    subs = [f for f in files if f.get("name", "").lower().endswith((".srt", ".vtt"))]
    subs.sort(key=lambda f: (
        0 if re.search(r"por|pt|bra", f.get("name", ""), re.I) else 1,
        1 if ".asr." in f.get("name", "").lower() else 0,
        f.get("name", "").lower(),
    ))
    return [file_url(ident, f["name"]) for f in subs]
