# -*- coding: utf-8 -*-
"""Base compartilhada: configurações, idioma, rede com cache, arquivos e itens de lista."""

import hashlib
import json
import os
import re
import sys
import time
import urllib.parse
import urllib.request

import xbmc
import xbmcaddon
import xbmcgui
import xbmcplugin
import xbmcvfs

ADDON = xbmcaddon.Addon()
ADDON_ID = ADDON.getAddonInfo("id")
ADDON_NAME = ADDON.getAddonInfo("name")
ADDON_VERSION = ADDON.getAddonInfo("version")
PROFILE = xbmcvfs.translatePath(ADDON.getAddonInfo("profile"))
ADDON_PATH = xbmcvfs.translatePath(ADDON.getAddonInfo("path"))

ICON = os.path.join(ADDON_PATH, "resources", "icon.png")
FANART = os.path.join(ADDON_PATH, "resources", "fanart.jpg")
CACHE_DIR = os.path.join(PROFILE, "cache")

BASE_URL = sys.argv[0] if sys.argv and sys.argv[0].startswith("plugin://") else "plugin://{}/".format(ADDON_ID)
HANDLE = int(sys.argv[1]) if len(sys.argv) > 1 and sys.argv[1].lstrip("-").isdigit() else -1

UA = "Mozilla/5.0 (Kodi; Sinexflix/{})".format(ADDON_VERSION)

_m = re.match(r"(\d+)", xbmc.getInfoLabel("System.BuildVersion") or "")
KODI_MAJOR = int(_m.group(1)) if _m else 19


# --------------------------------------------------------------------------
# Configurações e log
# --------------------------------------------------------------------------
def setting(key):
    return ADDON.getSetting(key)


def setting_int(key, default=0):
    try:
        return int(float(ADDON.getSetting(key) or default))
    except ValueError:
        return default


def setting_bool(key):
    return ADDON.getSetting(key) == "true"


def log(msg, level=xbmc.LOGINFO):
    xbmc.log("[Sinexflix] {}".format(msg), level)


def notify(msg, icon=None, ms=4000):
    xbmcgui.Dialog().notification(ADDON_NAME, msg, icon or ICON, ms)


def has_addon(addon_id):
    return bool(xbmc.getCondVisibility("System.HasAddon({})".format(addon_id)))


# --------------------------------------------------------------------------
# Idioma: o código usa textos em inglês dentro de _("...") e a tradução
# vem de resources/language/resource.language.<idioma>/strings.po
# --------------------------------------------------------------------------
_TRANSLATIONS = None


def _unquote_po(s):
    return s.replace('\\"', '"').replace("\\n", "\n").replace("\\\\", "\\")


def _load_po(path):
    table, msgid = {}, None
    try:
        with open(path, "r", encoding="utf-8") as fh:
            for line in fh:
                line = line.strip()
                if line.startswith("msgid "):
                    msgid = _unquote_po(line[7:-1])
                elif line.startswith("msgstr ") and msgid:
                    msgstr = _unquote_po(line[8:-1])
                    if msgstr:
                        table[msgid] = msgstr
                    msgid = None
    except OSError:
        pass
    return table


def ui_language():
    choice = setting_int("language", 1)   # 0 = automático, 1 = português, 2 = inglês
    if choice == 1:
        return "pt_br"
    if choice == 2:
        return "en_gb"
    lang = (xbmc.getLanguage(xbmc.ISO_639_1) or "").lower()
    return "pt_br" if lang.startswith("pt") else "en_gb"


def _(text):
    global _TRANSLATIONS
    if _TRANSLATIONS is None:
        lang = ui_language()
        _TRANSLATIONS = {} if lang == "en_gb" else _load_po(os.path.join(
            ADDON_PATH, "resources", "language", "resource.language." + lang, "strings.po"))
    return _TRANSLATIONS.get(text, text)


# --------------------------------------------------------------------------
# Arquivos
# --------------------------------------------------------------------------
def ensure_dir(path):
    if not os.path.isdir(path):
        os.makedirs(path, exist_ok=True)


def read_json_file(path, default):
    try:
        with open(path, "r", encoding="utf-8") as fh:
            return json.load(fh)
    except (OSError, ValueError):
        return default


def write_json_file(path, data):
    ensure_dir(os.path.dirname(path))
    tmp = path + ".tmp"
    with open(tmp, "w", encoding="utf-8") as fh:
        json.dump(data, fh, ensure_ascii=False)
    os.replace(tmp, path)


# --------------------------------------------------------------------------
# Rede com cache em disco
# --------------------------------------------------------------------------
def http_text(url, ttl=None, headers=None):
    """Baixa um texto com cache. Se a rede falhar, devolve o cache antigo."""
    if ttl is None:
        ttl = setting_int("cache_hours", 12) * 3600
    key = hashlib.md5(url.encode("utf-8")).hexdigest()
    path = os.path.join(CACHE_DIR, key + ".cache")

    def read_cache():
        try:
            with open(path, "r", encoding="utf-8") as fh:
                return fh.read()
        except OSError:
            return None

    if ttl > 0 and os.path.exists(path) and time.time() - os.path.getmtime(path) < ttl:
        cached = read_cache()
        if cached:
            return cached

    hdrs = {"User-Agent": UA}
    hdrs.update(headers or {})
    req = urllib.request.Request(url, headers=hdrs)
    try:
        with urllib.request.urlopen(req, timeout=25) as resp:
            text = resp.read().decode("utf-8", "replace")
    except Exception as exc:
        stale = read_cache()
        if stale:
            log("Usando cache antigo para {} ({})".format(url, exc), xbmc.LOGWARNING)
            return stale
        raise

    if ttl > 0:
        try:
            ensure_dir(CACHE_DIR)
            with open(path, "w", encoding="utf-8") as fh:
                fh.write(text)
        except OSError as exc:
            log("Falha ao gravar cache: {}".format(exc), xbmc.LOGWARNING)
    return text


def http_json(url, ttl=None, headers=None):
    return json.loads(http_text(url, ttl, headers))


def clear_cache():
    removed = 0
    if os.path.isdir(CACHE_DIR):
        for name in os.listdir(CACHE_DIR):
            try:
                os.remove(os.path.join(CACHE_DIR, name))
                removed += 1
            except OSError:
                pass
    notify(_("Cache cleared ({} files)").format(removed))


# --------------------------------------------------------------------------
# Textos
# --------------------------------------------------------------------------
def strip_html(text):
    text = re.sub(r"<br\s*/?>", "\n", text or "", flags=re.I)
    text = re.sub(r"<[^>]+>", "", text)
    return re.sub(r"\n{3,}", "\n\n", text).strip()


def first(value):
    """O Internet Archive às vezes devolve listas no lugar de strings."""
    if isinstance(value, list):
        return value[0] if value else ""
    return value or ""


def human_size(num):
    try:
        num = float(num)
    except (TypeError, ValueError):
        return ""
    for unit in ("B", "KB", "MB", "GB"):
        if num < 1024:
            return "{:.0f} {}".format(num, unit) if unit in ("B", "KB") else "{:.1f} {}".format(num, unit)
        num /= 1024
    return "{:.1f} TB".format(num)


def short_date(iso):
    """'2026-10-19' -> '19/10' (pt) ou '10/19' (en)."""
    try:
        y, m, d = iso[:10].split("-")
    except ValueError:
        return iso
    return "{}/{}".format(d, m) if ui_language() == "pt_br" else "{}/{}".format(m, d)


# --------------------------------------------------------------------------
# Itens de lista (compatível com Kodi 19, 20 e 21)
# --------------------------------------------------------------------------
def build_url(**params):
    clean = {k: v for k, v in params.items() if v not in (None, "")}
    return "{}?{}".format(BASE_URL, urllib.parse.urlencode(clean))


def apply_info(li, info):
    if not info:
        return
    if KODI_MAJOR < 20:
        li.setInfo("video", info)
        return
    tag = li.getVideoInfoTag()
    text_setters = {
        "title": tag.setTitle, "plot": tag.setPlot, "mediatype": tag.setMediaType,
        "tvshowtitle": tag.setTvShowTitle, "premiered": tag.setPremiered,
        "trailer": tag.setTrailer,
    }
    for key, fn in text_setters.items():
        if info.get(key):
            fn(str(info[key]))
    if info.get("year"):
        tag.setYear(int(info["year"]))
    if info.get("season") is not None:
        tag.setSeason(int(info["season"]))
    if info.get("episode") is not None:
        tag.setEpisode(int(info["episode"]))
    if info.get("duration"):
        tag.setDuration(int(info["duration"]))
    if info.get("rating"):
        tag.setRating(float(info["rating"]))
    if info.get("genre"):
        tag.setGenres(list(info["genre"]))
    if info.get("director"):
        tag.setDirectors(list(info["director"]))
    if info.get("cast"):
        tag.setCast([xbmc.Actor(name) for name in info["cast"]])
    if info.get("imdbnumber"):
        tag.setIMDBNumber(info["imdbnumber"])
        try:
            tag.setUniqueIDs({"imdb": info["imdbnumber"]}, "imdb")
        except Exception:
            pass


def make_item(label, info=None, art=None, path=None, playable=False, context=None):
    li = xbmcgui.ListItem(label=label, offscreen=True)
    if path and playable:
        li.setPath(path)
    art = {k: v for k, v in (art or {}).items() if v}
    art.setdefault("icon", ICON)
    art.setdefault("thumb", art.get("poster") or ICON)
    art.setdefault("fanart", FANART)
    li.setArt(art)
    apply_info(li, info)
    if playable:
        li.setProperty("IsPlayable", "true")
    if context:
        li.addContextMenuItems(context)
    return li


def add_folder(label, art=None, info=None, context=None, **params):
    li = make_item(label, info, art, context=context)
    xbmcplugin.addDirectoryItem(HANDLE, build_url(**params), li, isFolder=True)


def add_action(label, art=None, info=None, **params):
    li = make_item(label, info, art)
    xbmcplugin.addDirectoryItem(HANDLE, build_url(**params), li, isFolder=False)


def add_playable(label, url, art=None, info=None, context=None):
    li = make_item(label, info, art, path=url, playable=True, context=context)
    xbmcplugin.addDirectoryItem(HANDLE, url, li, isFolder=False)


def end_dir(content="files", category=None, sort=False, cache=True):
    if category:
        xbmcplugin.setPluginCategory(HANDLE, category)
    xbmcplugin.setContent(HANDLE, content)
    if sort:
        xbmcplugin.addSortMethod(HANDLE, xbmcplugin.SORT_METHOD_UNSORTED)
        xbmcplugin.addSortMethod(HANDLE, xbmcplugin.SORT_METHOD_LABEL_IGNORE_THE)
        xbmcplugin.addSortMethod(HANDLE, xbmcplugin.SORT_METHOD_VIDEO_YEAR)
        xbmcplugin.addSortMethod(HANDLE, xbmcplugin.SORT_METHOD_VIDEO_RATING)
    xbmcplugin.endOfDirectory(HANDLE, cacheToDisc=cache)


def resolve_failed():
    xbmcplugin.setResolvedUrl(HANDLE, False, xbmcgui.ListItem())


def refresh():
    xbmc.executebuiltin("Container.Refresh")
