# -*- coding: utf-8 -*-
"""Catálogo e informações de filmes e séries (Cinemeta, sem chave de API)."""

import re
import urllib.parse

from .common import _, http_json

CINEMETA = "https://v3-cinemeta.strem.io"
YT_PLUGIN = "plugin.video.youtube"

MOVIE_GENRES = ["Action", "Adventure", "Animation", "Biography", "Comedy", "Crime",
                "Documentary", "Drama", "Family", "Fantasy", "History", "Horror",
                "Mystery", "Romance", "Sci-Fi", "Sport", "Thriller", "War", "Western"]
SERIES_GENRES = MOVIE_GENRES + ["Reality-TV", "Talk-Show", "Game-Show"]


def genre_label(g):
    names = {
        "Action": _("Action"), "Adventure": _("Adventure"), "Animation": _("Animation"),
        "Biography": _("Biography"), "Comedy": _("Comedy"), "Crime": _("Crime"),
        "Documentary": _("Documentary"), "Drama": _("Drama"), "Family": _("Family"),
        "Fantasy": _("Fantasy"), "History": _("History"), "Horror": _("Horror"),
        "Mystery": _("Mystery"), "Romance": _("Romance"), "Sci-Fi": _("Science fiction"),
        "Sport": _("Sport"), "Thriller": _("Thriller"), "War": _("War"),
        "Western": _("Western"), "Reality-TV": _("Reality show"),
        "Talk-Show": _("Talk show"), "Game-Show": _("Game show"),
    }
    return names.get(g, g)


def meta_to_item(m, mtype):
    imdb = m.get("imdb_id") or m.get("id")
    if not imdb:
        return None
    name = m.get("name", "")
    rel = str(m.get("releaseInfo") or m.get("year") or "")
    poster = m.get("poster") or ""
    fanart = m.get("background") or poster
    genres = m.get("genres") or m.get("genre") or []

    info = {
        "title": name,
        "plot": m.get("description", ""),
        "mediatype": "movie" if mtype == "movie" else "tvshow",
        "genre": [genre_label(g) for g in genres],
        "imdbnumber": imdb,
    }
    if rel[:4].isdigit():
        info["year"] = int(rel[:4])
    try:
        info["rating"] = float(m.get("imdbRating") or 0)
    except ValueError:
        pass
    rt = re.search(r"(\d+)", str(m.get("runtime") or ""))
    if rt and mtype == "movie":
        info["duration"] = int(rt.group(1)) * 60
    for key in ("director", "cast"):
        if m.get(key):
            info[key] = m[key] if isinstance(m[key], list) else [m[key]]

    label = "{} ({})".format(name, rel) if rel else name
    if info.get("rating"):
        label += "  [COLOR gold]★ {:.1f}[/COLOR]".format(info["rating"])
    art = {"poster": poster, "thumb": poster, "fanart": fanart}
    if m.get("logo"):
        art["clearlogo"] = m["logo"]
    return {"label": label, "imdb": imdb, "name": name, "info": info, "art": art,
            "year": str(info.get("year", "")), "genres": genres, "type": mtype}


def catalog(mtype, cid="top", genre=None, search=None, skip=0):
    extra = []
    if search:
        extra.append("search=" + urllib.parse.quote(search))
    if genre:
        extra.append("genre=" + urllib.parse.quote(genre))
    if skip:
        extra.append("skip={}".format(int(skip)))
    url = "{}/catalog/{}/{}".format(CINEMETA, mtype, cid)
    if extra:
        url += "/" + "&".join(extra)
    url += ".json"
    metas = http_json(url).get("metas", []) or []
    return [x for x in (meta_to_item(m, mtype) for m in metas) if x]


def get_meta(mtype, imdb):
    return http_json("{}/meta/{}/{}.json".format(CINEMETA, mtype, imdb)).get("meta", {}) or {}


def trailer_ids(meta):
    ids = []
    for t in meta.get("trailerStreams") or []:
        if t.get("ytId"):
            ids.append((t.get("title") or "Trailer", t["ytId"]))
    for t in meta.get("trailers") or []:
        if t.get("source") and t["source"] not in [i for _x, i in ids]:
            ids.append((t.get("type") or "Trailer", t["source"]))
    return ids


def youtube_url(video_id):
    return "plugin://{}/play/?video_id={}".format(YT_PLUGIN, video_id)


def episode_number(v):
    return v.get("episode") or v.get("number") or 0


def release_date(v):
    return (v.get("released") or v.get("firstAired") or "")[:10]
