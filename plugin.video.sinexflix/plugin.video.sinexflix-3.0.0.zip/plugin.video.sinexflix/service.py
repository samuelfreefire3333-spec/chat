# -*- coding: utf-8 -*-
"""
Serviço do Sinexflix (roda em segundo plano enquanto o Kodi está aberto):
- avisa quando sai episódio novo de uma série da Minha Lista;
- testa os canais de TV ao vivo uma vez por dia (se ativado).
"""

import os
import time

import xbmc

from resources.lib import cinemeta, live, upcoming
from resources.lib.common import (PROFILE, _, log, notify, read_json_file, setting_bool,
                                  write_json_file)

SEEN_FILE = os.path.join(PROFILE, "avisados.json")


def check_new_episodes():
    if not setting_bool("notify_episodes"):
        return
    today = time.strftime("%Y-%m-%d")
    seen = read_json_file(SEEN_FILE, [])
    seen_set = set(seen)
    new = []
    for rel, show, meta, v in upcoming.collect(days_back=1, days_ahead=0):
        ep = cinemeta.episode_number(v)
        key = "{}:{}:{}".format(show["id"], v["season"], ep)
        if rel <= today and key not in seen_set:
            new.append("{} {}x{:02d}".format(meta.get("name", show["name"]), v["season"], ep))
            seen.append(key)
            seen_set.add(key)
    if not new:
        return
    if len(new) == 1:
        notify(_("New episode: {}").format(new[0]), ms=8000)
    else:
        notify(_("{} new episodes on your list").format(len(new)), ms=8000)
    write_json_file(SEEN_FILE, seen[-500:])


def check_live_channels(monitor):
    if not setting_bool("live_auto_check"):
        return
    age = live.last_check_age()
    if age is not None and age < 24 * 3600:
        return
    if xbmc.Player().isPlaying():
        return   # não atrapalha quem está assistindo
    log("Testando canais de TV ao vivo em segundo plano")
    live.check_all(progress=lambda done, total: not monitor.abortRequested(), workers=12)


def run():
    monitor = xbmc.Monitor()
    if monitor.waitForAbort(90):      # espera o Kodi terminar de abrir
        return
    while not monitor.abortRequested():
        for task in (check_new_episodes, lambda: check_live_channels(monitor)):
            try:
                task()
            except Exception as exc:
                log("Serviço: {}".format(exc), xbmc.LOGWARNING)
        if monitor.waitForAbort(6 * 3600):
            break


if __name__ == "__main__":
    run()
